package com.assignment.faizanelahi.kogancodingchallenge.Model;

public class AirConditioner {

    private int id;
    private String Title;
    private String width;
    private String length;
    private String height;
    private double cubic_weight;

    public AirConditioner(){}

    public AirConditioner(int id, String Title, String width, String length, String height){
        this.id = id;
        this.Title = Title;
        this.width = width;
        this.length = length;
        this.height = height;

    }

    public String getTitle() {
        return Title;
    }

    public String getWidth() {
        return width;
    }

    public String getLength() {
        return length;
    }

    public String getHeight() {
        return height;
    }

    public double getCubic_weight() {
        return cubic_weight;
    }

    public void setTitle(String title) {
        Title = title;
    }

    public void setWidth(String width) {
        this.width = width;
    }

    public void setLength(String length) {
        this.length = length;
    }

    public void setHeight(String height) {
        this.height = height;
    }

    public void setCubic_weight(double cubic_weight) {
        this.cubic_weight = cubic_weight;
    }
}
