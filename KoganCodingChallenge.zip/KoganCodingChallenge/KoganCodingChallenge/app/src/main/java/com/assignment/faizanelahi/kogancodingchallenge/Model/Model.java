package com.assignment.faizanelahi.kogancodingchallenge.Model;

import java.util.ArrayList;
import java.util.List;

public class Model {

    private List<AirConditioner> airConditioners;

    // Using singleton to have access across the app
    private static Model ms= new Model();

    private Model() {
        this.airConditioners= new ArrayList<>();
    }

    public void addairConditoner(AirConditioner ac){
        airConditioners.add(ac);
    }

    public List<AirConditioner> getAirConditioners() {
        return airConditioners;
    }

    // Used to return singleton instance
    public static Model getInstance(){ return ms;}
}
