package com.assignment.faizanelahi.kogancodingchallenge.Service;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.util.Log;

import com.assignment.faizanelahi.kogancodingchallenge.Model.AirConditioner;
import com.assignment.faizanelahi.kogancodingchallenge.Model.Model;
import com.assignment.faizanelahi.kogancodingchallenge.View.ItemsActivity;
import com.assignment.faizanelahi.kogancodingchallenge.View.MainActivity;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;

import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

public class RESTcall extends AsyncTask<String, Void, String> {

    ProgressDialog pd;
    Context mContext;

    public RESTcall(Context mContext) {
        this.mContext = mContext;
    }

        protected void onPreExecute() {
            super.onPreExecute();
            pd=new ProgressDialog(mContext);
            pd.setMessage("Loading");
            pd.setCancelable(false);
            pd.show();
        }
        @Override
        protected String doInBackground(String... params) {
            int id= 0;

            OkHttpClient client= new OkHttpClient();

            Request request= new Request.Builder()
                    .url("http://wp8m3he1wt.s3-website-ap-southeast-2.amazonaws.com/api/products/1")
                    .build();
            Response response= null;
            try {
                response = client.newCall(request).execute();
                String res= response.body().string();
                JSONObject root= new JSONObject( res);
                JSONArray Obj = root.getJSONArray("objects");
                for (int i=0; i< Obj.length(); i++){
                    JSONObject o = Obj.getJSONObject(i);
                    if (o.getString("category").equals("Air Conditioners")){
                        String title= o.getString("title");
                        Log.d("Title", title);
                        JSONObject main  = o.getJSONObject("size");
                        String width = main.getString("width");
                        String length = main.getString("length");
                        String height = main.getString("height");
                        Log.d("Height", width);
                        Log.d("Height", length);
                        Log.d("Height", height);
                        AirConditioner ac= new AirConditioner(id, title, width, length, height);
                        Model.getInstance().addairConditoner(ac);
                    }
                }

            }catch (IOException e){
                e.printStackTrace();
            }catch (JSONException e) {
                Log.d("error","error3");
            }
            return null;
        }

        @Override
        protected void onPostExecute(String o) {
            super.onPostExecute(o);
            pd.dismiss();

            Intent intent= new Intent(mContext, ItemsActivity.class);
            mContext.startActivity(intent);
        }
}
