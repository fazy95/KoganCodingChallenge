package com.assignment.faizanelahi.kogancodingchallenge.View;

import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.assignment.faizanelahi.kogancodingchallenge.Model.AirConditioner;
import com.assignment.faizanelahi.kogancodingchallenge.Model.Model;
import com.assignment.faizanelahi.kogancodingchallenge.R;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import okhttp3.Response;

import static android.widget.Toast.makeText;

public class ItemsActivity extends AppCompatActivity {

    private TextView title;
    private TextView width;
    private TextView length;
    private TextView height;
    private TextView cubicWeight;
    private Button next;
    List<AirConditioner> acList= new ArrayList<>();
    AirConditioner ac= new AirConditioner();

    int i= 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_items);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        acList= Model.getInstance().getAirConditioners();
        title = findViewById(R.id.title);
        width = findViewById(R.id.width);
        length = findViewById(R.id.length);
        height = findViewById(R.id.height);
        cubicWeight = findViewById(R.id.cubic_weight);
        next = findViewById(R.id.next);

        ac= acList.get(0);

        title.setText(ac.getTitle());
        width.setText(ac.getWidth());
        length.setText(ac.getLength());
        height.setText(ac.getHeight());
        double cw= calculateCubicWeight(ac.getWidth(), ac.getLength(),ac.getHeight());
        String f = new DecimalFormat("##.##").format(cw);
        cubicWeight.setText(f);
        next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (i<= acList.size()) {
                    ac = acList.get(i);

                    title.setText(ac.getTitle());
                    width.setText(ac.getWidth());
                    length.setText(ac.getLength());
                    height.setText(ac.getHeight());
                    double cw = calculateCubicWeight(ac.getWidth(), ac.getLength(), ac.getHeight());
                    String f = new DecimalFormat("##.##").format(cw);
                    cubicWeight.setText(f);
                    i++;
                }
                Toast.makeText(getApplicationContext(),
                        "There are no more items on the list",
                        Toast.LENGTH_SHORT).show();
                i++;
            }
        });

    }

    public double calculateCubicWeight(String widthp, String lengthp, String heightp){
        double cubicWeight= 0;
        double width= Double.parseDouble(widthp);
        double length= Double.parseDouble(lengthp);
        double height = Double.parseDouble(heightp);

        cubicWeight= ((width/100)* (length/100)* (height/100))*250;
        return cubicWeight;
    }

}
